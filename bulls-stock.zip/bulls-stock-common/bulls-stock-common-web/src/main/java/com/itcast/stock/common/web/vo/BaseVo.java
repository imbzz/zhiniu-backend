package com.itcast.stock.common.web.vo;

import java.io.Serializable;

/**
 * <p>Description: </p>
 * @date 2020/1/7
 * @author 贺锟 
 * @version 1.0
 * <p>Copyright:Copyright(c)2019</p>
 */
public class BaseVo implements Serializable {
}
