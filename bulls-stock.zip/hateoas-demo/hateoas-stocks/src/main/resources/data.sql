insert into t_stocks(name, price, create_time, update_time) values('中国平安', 86.6, now(), now());
insert into t_stocks(name, price, create_time, update_time) values('工商银行', 6.6, now(), now());
insert into t_stocks(name, price, create_time, update_time) values('招商银行', 26.6, now(), now());

